
<!DOCTYPE html>
<html>
<head>
<title>.::My Mobile Shop::.</title>   
<link rel="stylesheet" href="style.css"> 
</head>
<body>
<div class="html">
	<div class="head">
		<img src="img/lo1.png">    
	</div>  
	<div class="menu"> 
		<ul>
			<li><a href="index.php">Home</a></li>
			<li><a href="project.php">Shop</a></li>
			<li><a href="contact.php">Contact</a></li>
			<li style="border-right:none"><a href="#">Registration</a></li>
		</ul>
	</div><hr><hr>
    <div class="sig">
		<h1><a href="admin/index.php">SIGN IN</a> </h1>
    </div>
    <div class="mobil">
		<img src="img/bakp.png">
    </div>
    <div class="text">
		<pre>
			<h1>Welcome to my mobile shop</h1>
			<h2>Here you can find all the gadgets like tablets<br>smartphones and accesories at a very reasonable<br>price. All the latest and greatest deal of all<br>the branded product are available</h2>
		</pre>
    </div>
    <div class="text1">
		<pre>
		<h2>We offer one of the most popular and best brand<br>products like Samsung , Apple, HTC, Blackberry,<br>Lenovo, Huawei Asus, Oneplus, LG and many more.<br>One of our latest line up inlcludes LG G5,Apple<br>Iphone 6S, Samsung Galaxy S7, HTC One M9, Oneplus<br>2 etc.</h2>
		</pre> 
    </div>
</div>
         
</body>
</html>