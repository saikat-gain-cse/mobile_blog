<html>
<head>
<style>
table{
    width:100%;
	height:auto; 
	margin:5px auto;
	text-align:center;
}
table tr th,td{
    width:17%;
	border:1px solid red;    
}
table input{
	width:100%;
	border:none;
}
</style> 
</head>
<body>